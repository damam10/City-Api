package com.ritik.CityProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CityProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
